<?php
/* Central database connection for the whole Hospital Management System. */
$host = "localhost";
$user = "root";
$password = "Balu1@2@";
$database = "hospital_management";

$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
    die("Database connection failed: " . htmlspecialchars($conn->connect_error));
}
$conn->set_charset("utf8mb4");

/*
 * Create the project's tables if they are missing.
 * This keeps all modules on the same schema and avoids table/column mismatch errors.
 */
$schema = [
"CREATE TABLE IF NOT EXISTS departments (
    dept_id INT AUTO_INCREMENT PRIMARY KEY,
    dept_name VARCHAR(100) NOT NULL UNIQUE
) ENGINE=InnoDB",

"CREATE TABLE IF NOT EXISTS patients (
    patient_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    age INT NOT NULL,
    gender VARCHAR(10) NOT NULL,
    phone VARCHAR(15),
    address VARCHAR(200)
) ENGINE=InnoDB",

"CREATE TABLE IF NOT EXISTS doctors (
    doctor_id INT AUTO_INCREMENT PRIMARY KEY,
    dept_id INT NULL,
    name VARCHAR(100) NOT NULL,
    specialization VARCHAR(100) NOT NULL,
    consultation_fee DECIMAL(10,2) NOT NULL DEFAULT 0,
    CONSTRAINT fk_doctor_department FOREIGN KEY (dept_id)
        REFERENCES departments(dept_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB",

"CREATE TABLE IF NOT EXISTS rooms (
    room_id INT AUTO_INCREMENT PRIMARY KEY,
    room_type VARCHAR(50) NOT NULL,
    cost_per_day DECIMAL(10,2) NOT NULL DEFAULT 0,
    is_occupied TINYINT(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB",

"CREATE TABLE IF NOT EXISTS appointments (
    appointment_id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    doctor_id INT NOT NULL,
    appointment_date DATE NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'Scheduled',
    CONSTRAINT fk_appointment_patient FOREIGN KEY (patient_id)
        REFERENCES patients(patient_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_appointment_doctor FOREIGN KEY (doctor_id)
        REFERENCES doctors(doctor_id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB",

"CREATE TABLE IF NOT EXISTS admissions (
    admission_id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    room_id INT NULL,
    admission_date DATE NOT NULL,
    discharge_date DATE NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'Admitted',
    CONSTRAINT fk_admission_patient FOREIGN KEY (patient_id)
        REFERENCES patients(patient_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_admission_room FOREIGN KEY (room_id)
        REFERENCES rooms(room_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB",

"CREATE TABLE IF NOT EXISTS medical_records (
    record_id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    doctor_id INT NULL,
    visit_date DATE NOT NULL,
    diagnosis VARCHAR(255) NOT NULL,
    notes TEXT,
    CONSTRAINT fk_record_patient FOREIGN KEY (patient_id)
        REFERENCES patients(patient_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_record_doctor FOREIGN KEY (doctor_id)
        REFERENCES doctors(doctor_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB",

"CREATE TABLE IF NOT EXISTS prescriptions (
    prescription_id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    doctor_id INT NULL,
    medicine VARCHAR(150) NOT NULL,
    dosage VARCHAR(100),
    instructions VARCHAR(255),
    prescription_date DATE NOT NULL,
    CONSTRAINT fk_prescription_patient FOREIGN KEY (patient_id)
        REFERENCES patients(patient_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_prescription_doctor FOREIGN KEY (doctor_id)
        REFERENCES doctors(doctor_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB",

"CREATE TABLE IF NOT EXISTS patient_files (
    file_id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    category VARCHAR(40) NOT NULL,
    title VARCHAR(150) NOT NULL,
    original_name VARCHAR(255) NOT NULL,
    stored_name VARCHAR(100) NOT NULL UNIQUE,
    mime_type VARCHAR(100) NOT NULL,
    file_size BIGINT UNSIGNED NOT NULL,
    record_date DATE NOT NULL,
    uploaded_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_patient_files_patient_date (patient_id, record_date),
    CONSTRAINT fk_patient_files_patient FOREIGN KEY (patient_id)
        REFERENCES patients(patient_id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB",

"CREATE TABLE IF NOT EXISTS bills (
    bill_id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    admission_id INT NULL,
    doctor_charge DECIMAL(10,2) NOT NULL DEFAULT 0,
    room_charge DECIMAL(10,2) NOT NULL DEFAULT 0,
    other_charge DECIMAL(10,2) NOT NULL DEFAULT 0,
    total_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
    bill_date DATE NOT NULL,
    payment_status VARCHAR(30) NOT NULL DEFAULT 'Pending',
    CONSTRAINT fk_bill_patient FOREIGN KEY (patient_id)
        REFERENCES patients(patient_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_bill_admission FOREIGN KEY (admission_id)
        REFERENCES admissions(admission_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB",

"CREATE TABLE IF NOT EXISTS bill_items (
    bill_item_id INT AUTO_INCREMENT PRIMARY KEY,
    bill_id INT NOT NULL,
    item_type VARCHAR(30) NOT NULL,
    description VARCHAR(200) NOT NULL,
    quantity DECIMAL(10,2) NOT NULL DEFAULT 1,
    unit_price DECIMAL(10,2) NOT NULL DEFAULT 0,
    line_total DECIMAL(10,2) NOT NULL DEFAULT 0,
    CONSTRAINT fk_bill_item_bill FOREIGN KEY (bill_id)
        REFERENCES bills(bill_id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB"
];

foreach ($schema as $sql) {
    if (!$conn->query($sql)) {
        die("Database setup error: " . htmlspecialchars($conn->error));
    }
}

/* Add a few demo departments/doctors/rooms only when those tables are empty. */
if (($conn->query("SELECT COUNT(*) c FROM departments")->fetch_assoc()['c'] ?? 0) == 0) {
    $conn->query("INSERT INTO departments (dept_name) VALUES
        ('General Medicine'),('Cardiology'),('Orthopedics'),('Pediatrics'),('Neurology')");
}
if (($conn->query("SELECT COUNT(*) c FROM doctors")->fetch_assoc()['c'] ?? 0) == 0) {
    $conn->query("INSERT INTO doctors (dept_id,name,specialization,consultation_fee)
        SELECT dept_id,'Dr. Ananya Rao','General Physician',500 FROM departments WHERE dept_name='General Medicine'
        UNION ALL
        SELECT dept_id,'Dr. Rahul Mehta','Cardiologist',800 FROM departments WHERE dept_name='Cardiology'
        UNION ALL
        SELECT dept_id,'Dr. Priya Sharma','Orthopedic Specialist',700 FROM departments WHERE dept_name='Orthopedics'");
}
if (($conn->query("SELECT COUNT(*) c FROM rooms")->fetch_assoc()['c'] ?? 0) == 0) {
    $conn->query("INSERT INTO rooms (room_type,cost_per_day,is_occupied) VALUES
        ('General Ward',1000,0),('Semi Private',2000,0),('Private Room',3500,0),('ICU',5000,0)");
}
?>
