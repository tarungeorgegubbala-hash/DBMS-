<?php
if (session_status() === PHP_SESSION_NONE) session_start();
$scriptPath = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '/');
$scriptDirectory = rtrim(dirname($scriptPath), '/');
$moduleDirectories = ['patients', 'appointments', 'doctors', 'admissions', 'prescriptions', 'billing', 'settings'];
$directoryName = basename($scriptDirectory);
$basePath = in_array($directoryName, $moduleDirectories, true) ? dirname($scriptDirectory) : $scriptDirectory;
$basePath = str_replace('\\', '/', $basePath);
$basePath = $basePath === '/' || $basePath === '.' ? '' : rtrim($basePath, '/');
$current = in_array($directoryName, $moduleDirectories, true) ? $directoryName : basename($scriptPath);
if ($directoryName === 'doctors' && basename($scriptPath) === 'departments.php') $current = 'departments.php';
$pageTitle = $pageTitle ?? "Dashboard";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($pageTitle) ?> | Hospital Management</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= htmlspecialchars($basePath) ?>/assets/css/style.css">
<link rel="stylesheet" href="<?= htmlspecialchars($basePath) ?>/assets/css/enhancements.css">
</head>
<body>
<div class="app">
<aside class="sidebar">
  <div class="brand">
    <div class="brand-icon">✚</div>
    <div><b>Hospital<br>Management</b></div>
  </div>
  <nav>
    <a href="<?= htmlspecialchars($basePath) ?>/" class="<?= $current==='index.php'?'active':'' ?>"><span>⌂</span>Dashboard</a>
    <a href="<?= htmlspecialchars($basePath) ?>/patients/" class="<?= $current==='patients'?'active':'' ?>"><span>♙</span>Patients</a>
    <a href="<?= htmlspecialchars($basePath) ?>/appointments/" class="<?= $current==='appointments'?'active':'' ?>"><span>◫</span>Appointments</a>
    <a href="<?= htmlspecialchars($basePath) ?>/doctors/" class="<?= $current==='doctors'?'active':'' ?>"><span>♟</span>Doctors</a>
    <a href="<?= htmlspecialchars($basePath) ?>/doctors/departments.php" class="<?= $current==='departments.php'?'active':'' ?>"><span>▦</span>Departments</a>
    <a href="<?= htmlspecialchars($basePath) ?>/admissions/" class="<?= $current==='admissions'?'active':'' ?>"><span>▣</span>Medical Records</a>
    <a href="<?= htmlspecialchars($basePath) ?>/prescriptions/" class="<?= $current==='prescriptions'?'active':'' ?>"><span>▤</span>Prescriptions</a>
    <a href="<?= htmlspecialchars($basePath) ?>/billing/" class="<?= $current==='billing'?'active':'' ?>"><span>▤</span>Billing & Payments</a>
    <a href="<?= htmlspecialchars($basePath) ?>/reports.php" class="<?= $current==='reports.php'?'active':'' ?>"><span>▥</span>Reports</a>
    <a href="<?= htmlspecialchars($basePath) ?>/settings/" class="<?= $current==='settings'?'active':'' ?>"><span>⚙</span>Settings</a>
  </nav>
  <div class="sidebar-bottom">
    <div class="mini-profile"><div class="avatar">DR</div><div><b>Administrator</b><small>Hospital Admin</small></div></div>
    <a href="<?= htmlspecialchars($basePath) ?>/login.php?logout=1" class="logout"><span>↪</span>Logout</a>
  </div>
</aside>
<main class="main">
<header class="topbar">
  <div class="search"><span>⌕</span><input placeholder="Search this page..." id="globalSearch" aria-label="Search this page"></div>
  <div class="top-actions">
    <button class="icon-btn" id="notificationsButton" type="button" aria-label="Notifications" aria-expanded="false" title="Notifications">♧</button>
    <button class="icon-btn" id="themeToggle" type="button" aria-label="Switch to dark mode" title="Switch to dark mode">☾</button>
    <div class="user">DR <span>Dr. Administrator</span></div>
  </div>
  <div class="notification-popover" id="notificationsPopover" hidden role="status">You are all caught up.</div>
</header>
<div class="content">