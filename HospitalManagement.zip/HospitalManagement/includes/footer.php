</div>
<footer class="footer"><span>♥ Healthier Communities</span><span>•</span><span>Better Care</span><span>•</span><span>Brighter Future</span></footer>
</main></div>
<script src="<?= htmlspecialchars($basePath) ?>/assets/js/app.js"></script>
</body>
</html>