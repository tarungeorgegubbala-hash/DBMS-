<?php
require_once "includes/db.php";
$pageTitle = "Reports";
$patients = (int)($conn->query("SELECT COUNT(*) c FROM patients")->fetch_assoc()['c'] ?? 0);
$appointments = (int)($conn->query("SELECT COUNT(*) c FROM appointments")->fetch_assoc()['c'] ?? 0);
$revenue = (float)($conn->query("SELECT COALESCE(SUM(total_amount),0) c FROM bills")->fetch_assoc()['c'] ?? 0);
$outstanding = (float)($conn->query("SELECT COALESCE(SUM(total_amount),0) c FROM bills WHERE payment_status <> 'Paid'")->fetch_assoc()['c'] ?? 0);

$chargeRow = $conn->query("SELECT COALESCE(SUM(doctor_charge),0) doctor_total, COALESCE(SUM(room_charge),0) room_total FROM bills")->fetch_assoc();
$chargeLabels = ['Doctor', 'Room'];
$chargeValues = [(float)$chargeRow['doctor_total'], (float)$chargeRow['room_total']];
$maxCharge = max(1, ...$chargeValues);
$paymentResult = $conn->query("SELECT payment_status, COUNT(*) total, SUM(total_amount) amount FROM bills GROUP BY payment_status ORDER BY total DESC");

include "includes/header.php";
?>
<div class="page-head"><div><h1>Reports</h1><p>Live activity and billing summaries.</p></div><button class="btn" type="button" onclick="window.print()">Print report</button></div>
<div class="stats">
	<div class="card stat"><div><div class="stat-icon">♙</div><h3><?= $patients ?></h3><p>Total Patients</p></div></div>
	<div class="card stat"><div><div class="stat-icon">◫</div><h3><?= $appointments ?></h3><p>Total Appointments</p></div></div>
	<div class="card stat"><div><div class="stat-icon">₹</div><h3>₹<?= number_format($revenue, 0) ?></h3><p>Recorded Revenue</p></div></div>
	<div class="card stat"><div><div class="stat-icon">◷</div><h3>₹<?= number_format($outstanding, 0) ?></h3><p>Outstanding Bills</p></div></div>
</div>
<div class="grid3 reports-grid">
	<div class="card panel reports-chart">
		<h2>Charges by Category</h2>
		<div class="chart" role="img" aria-label="Doctor and room charges">
			<?php foreach ($chargeLabels as $i => $label): $height = $chargeValues[$i] ? max(5, (int)round($chargeValues[$i] / $maxCharge * 100)) : 2; ?>
			<div class="bar" style="height:<?= $height ?>%" data-day="<?= $label ?>" title="<?= $label ?> charges: ₹<?= number_format($chargeValues[$i], 2) ?>" aria-label="<?= $label ?> charges: ₹<?= number_format($chargeValues[$i], 2) ?>"></div>
			<?php endforeach; ?>
		</div>
	</div>
	<div class="card panel">
		<h2>Payments by Status</h2>
		<div class="table-wrap"><table class="table"><thead><tr><th>Status</th><th>Bills</th><th>Amount</th></tr></thead><tbody>
		<?php if ($paymentResult && $paymentResult->num_rows): while ($payment = $paymentResult->fetch_assoc()): ?>
			<tr><td><?= htmlspecialchars($payment['payment_status']) ?></td><td><?= (int)$payment['total'] ?></td><td>₹<?= number_format((float)$payment['amount'], 2) ?></td></tr>
		<?php endwhile; else: ?><tr><td colspan="3">No billing records yet.</td></tr><?php endif; ?>
		</tbody></table></div>
	</div>
</div>
<?php include "includes/footer.php";?>