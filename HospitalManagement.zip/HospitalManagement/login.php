<?php
if (session_status() === PHP_SESSION_NONE) session_start();
$basePath = str_replace('\\', '/', dirname(str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '/')));
$basePath = $basePath === '/' ? '' : rtrim($basePath, '/');
if (isset($_GET['logout'])) {
	$_SESSION = [];
	session_destroy();
}
if (isset($_POST['login'])) {
	$_SESSION['admin'] = true;
	header("Location: index.php");
	exit;
}
?>
<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Hospital Management Login</title><link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet"><link rel="stylesheet" href="<?= htmlspecialchars($basePath) ?>/assets/css/style.css"><link rel="stylesheet" href="<?= htmlspecialchars($basePath) ?>/assets/css/enhancements.css"></head><body>
<div class="login-page"><div class="login-box"><div class="login-art"><div class="brand"><div class="brand-icon">✚</div><div><b>Hospital Management</b></div></div><h1>Hospital Management</h1><p>Manage patients, doctors, appointments and hospital operations from one workspace.</p><div style="font-size:40px;margin-top:20px">♡</div></div>
<div class="login-form"><h2>Welcome Back</h2><p>Sign in to your hospital administrator account</p><form method="post"><label>Email or Username</label><input name="username" placeholder="Enter username" required><label>Password</label><input type="password" name="password" placeholder="Enter password" required><button class="btn" name="login">Login</button></form></div></div></div></body></html>