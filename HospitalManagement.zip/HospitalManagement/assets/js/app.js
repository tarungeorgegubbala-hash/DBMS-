document.addEventListener("DOMContentLoaded", () => {
	const themeKey = "hospital-management-theme";
	const themeButton = document.getElementById("themeToggle");
	const themeSetting = document.getElementById("darkModeSetting");
	const notificationButton = document.getElementById("notificationsButton");
	const notificationPopover = document.getElementById("notificationsPopover");

	const applyTheme = (dark) => {
		document.body.classList.toggle("dark-mode", dark);
		localStorage.setItem(themeKey, dark ? "dark" : "light");
		if (themeButton) {
			themeButton.textContent = dark ? "☀" : "☾";
			themeButton.setAttribute("aria-label", `Switch to ${dark ? "light" : "dark"} mode`);
			themeButton.title = `Switch to ${dark ? "light" : "dark"} mode`;
		}
		if (themeSetting) themeSetting.checked = dark;
	};

	applyTheme(localStorage.getItem(themeKey) === "dark");
	themeButton?.addEventListener("click", () => {
		applyTheme(!document.body.classList.contains("dark-mode"));
	});
	themeSetting?.addEventListener("change", () => applyTheme(themeSetting.checked));

	document.querySelectorAll("[data-preference]").forEach((control) => {
		const key = `hospital-management-${control.dataset.preference}`;
		control.checked = localStorage.getItem(key) === "true";
		const applyPreference = () => {
			localStorage.setItem(key, String(control.checked));
			document.body.classList.toggle(control.dataset.preference, control.checked);
		};
		applyPreference();
		control.addEventListener("change", applyPreference);
	});

	notificationButton?.addEventListener("click", () => {
		const isOpen = notificationButton.getAttribute("aria-expanded") === "true";
		notificationPopover.textContent = localStorage.getItem("hospital-management-notifications-enabled") === "true"
			? "You are all caught up."
			: "In-app notifications are turned off in Settings.";
		notificationButton.setAttribute("aria-expanded", String(!isOpen));
		notificationPopover.hidden = isOpen;
	});
	document.addEventListener("click", (event) => {
		if (!notificationButton?.contains(event.target) && !notificationPopover?.contains(event.target)) {
			notificationPopover.hidden = true;
			notificationButton?.setAttribute("aria-expanded", "false");
		}
	});

	const search = document.getElementById("globalSearch");
	search?.addEventListener("input", () => {
		const query = search.value.trim().toLocaleLowerCase();
		document.querySelectorAll(".table tbody tr, .list-row, .doctor").forEach((item) => {
			item.hidden = !item.textContent.toLocaleLowerCase().includes(query);
		});
	});
});