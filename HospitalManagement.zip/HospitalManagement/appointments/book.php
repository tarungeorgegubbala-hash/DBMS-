<?php require_once "../includes/db.php"; $pageTitle="Book Appointment"; $msg="";
if($_SERVER["REQUEST_METHOD"]==="POST"){ $st=$conn->prepare("INSERT INTO appointments(patient_id,doctor_id,appointment_date,status) VALUES(?,?,?,?)"); $status="Scheduled"; $st->bind_param("iiss",$_POST['patient_id'],$_POST['doctor_id'],$_POST['appointment_date'],$status); if($st->execute()) header("Location: index.php"); else $msg=$st->error;}
include "../includes/header.php"; ?>
<div class="page-head"><div><h1>Book Appointment</h1><p>Schedule a visit with a doctor.</p></div></div>
<div class="card form-card"><?php if($msg):?><div class="error"><?=$msg?></div><?php endif;?><form method="post" class="form">
<label>Patient<select name="patient_id" required><option value="">Select Patient</option><?php $rs=$conn->query("SELECT patient_id,name FROM patients ORDER BY name");while($x=$rs->fetch_assoc()):?><option value="<?=$x['patient_id']?>"><?=htmlspecialchars($x['name'])?></option><?php endwhile;?></select></label>
<label>Doctor<select name="doctor_id" required><option value="">Select Doctor</option><?php $rs=$conn->query("SELECT doctor_id,name,specialization FROM doctors ORDER BY name");while($x=$rs->fetch_assoc()):?><option value="<?=$x['doctor_id']?>"><?=htmlspecialchars($x['name'])?> — <?=htmlspecialchars($x['specialization'])?></option><?php endwhile;?></select></label>
<label>Appointment Date<input type="date" name="appointment_date" required></label>
<div class="actions full"><button class="btn" type="submit">Book Appointment</button><a class="btn light" href="index.php">Cancel</a></div>
</form></div>
<?php include "../includes/footer.php";?>