<?php require_once "../includes/db.php"; $pageTitle="Departments"; include "../includes/header.php"; ?>
<div class="page-head"><div><h1>Departments</h1><p>Hospital departments and specialties.</p></div></div>
<div class="doctors"><?php $rs=$conn->query("SELECT * FROM departments ORDER BY dept_id"); while($r=$rs->fetch_assoc()):?><div class="card doctor"><div class="stat-icon" style="margin:auto">✚</div><h3><?=htmlspecialchars($r['dept_name'])?></h3><p>Hospital Department</p></div><?php endwhile;?></div>
<?php include "../includes/footer.php";?>