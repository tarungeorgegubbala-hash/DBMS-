<?php require_once "../includes/db.php"; $pageTitle="Prescriptions"; $msg="";
if($_SERVER["REQUEST_METHOD"]==="POST"){
 $pid=(int)$_POST['patient_id'];$date=$_POST['prescription_date'];$did=(int)($_POST['doctor_id']??0);
 if($did>0){
   $st=$conn->prepare("INSERT INTO prescriptions(patient_id,doctor_id,medicine,dosage,instructions,prescription_date) VALUES(?,?,?,?,?,?)");
   $st->bind_param("iissss",$pid,$did,$_POST['medicine'],$_POST['dosage'],$_POST['instructions'],$date);
 } else {
   $st=$conn->prepare("INSERT INTO prescriptions(patient_id,doctor_id,medicine,dosage,instructions,prescription_date) VALUES(?,NULL,?,?,?,?)");
   $st->bind_param("issss",$pid,$_POST['medicine'],$_POST['dosage'],$_POST['instructions'],$date);
 }
 if(!$st->execute())$msg=$st->error;
}
include "../includes/header.php";?>
<div class="page-head"><div><h1>Prescriptions</h1><p>Create and review patient prescriptions.</p></div></div>
<div class="card form-card compact"><?php if($msg):?><div class="error"><?=htmlspecialchars($msg)?></div><?php endif;?><h2>New Prescription</h2>
<form method="post" class="form"><label>Patient<select name="patient_id" required><option value="">Select Patient</option><?php $rs=$conn->query("SELECT patient_id,name FROM patients ORDER BY name");while($r=$rs->fetch_assoc()):?><option value="<?=$r['patient_id']?>"><?=htmlspecialchars($r['name'])?></option><?php endwhile;?></select></label>
<label>Doctor<select name="doctor_id"><option value="0">Select Doctor</option><?php $rs=$conn->query("SELECT doctor_id,name FROM doctors ORDER BY name");while($r=$rs->fetch_assoc()):?><option value="<?=$r['doctor_id']?>"><?=htmlspecialchars($r['name'])?></option><?php endwhile;?></select></label>
<label>Medicine<input name="medicine" required></label><label>Dosage<input name="dosage" placeholder="e.g. 1 tablet twice daily"></label><label class="full">Instructions<textarea name="instructions"></textarea></label><label>Date<input type="date" name="prescription_date" value="<?=date('Y-m-d')?>" required></label><div class="actions full"><button class="btn">Save Prescription</button></div></form></div>
<div class="card panel"><div class="table-wrap"><table class="table"><thead><tr><th>ID</th><th>Patient</th><th>Doctor</th><th>Medicine</th><th>Dosage</th><th>Date</th></tr></thead><tbody>
<?php $sql="SELECT pr.*,p.name patient_name,d.name doctor_name FROM prescriptions pr JOIN patients p ON p.patient_id=pr.patient_id LEFT JOIN doctors d ON d.doctor_id=pr.doctor_id ORDER BY pr.prescription_id DESC";$rs=$conn->query($sql);while($r=$rs->fetch_assoc()):?><tr><td>RX-<?=$r['prescription_id']?></td><td><?=htmlspecialchars($r['patient_name'])?></td><td><?=htmlspecialchars($r['doctor_name']??'—')?></td><td><?=htmlspecialchars($r['medicine'])?></td><td><?=htmlspecialchars($r['dosage']??'')?></td><td><?=$r['prescription_date']?></td></tr><?php endwhile;?>
</tbody></table></div></div>
<?php include "../includes/footer.php";?>
