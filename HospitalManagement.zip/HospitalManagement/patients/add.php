<?php require_once "../includes/db.php"; $pageTitle="Add Patient"; $msg="";
if($_SERVER["REQUEST_METHOD"]==="POST"){ $st=$conn->prepare("INSERT INTO patients(name,age,gender,phone,address) VALUES(?,?,?,?,?)"); $st->bind_param("sisss",$_POST['name'],$_POST['age'],$_POST['gender'],$_POST['phone'],$_POST['address']); if($st->execute()) header("Location: index.php"); else $msg=$st->error; }
include "../includes/header.php"; ?>
<div class="page-head"><div><h1>Add Patient</h1><p>Register a new patient in the hospital database.</p></div></div>
<div class="card form-card"><?php if($msg):?><div class="error"><?=$msg?></div><?php endif;?><form method="post" class="form">
<label>Patient Name<input name="name" required></label><label>Age<input type="number" name="age" min="0" required></label>
<label>Gender<select name="gender" required><option>Male</option><option>Female</option><option>Other</option></select></label><label>Phone<input name="phone"></label>
<label class="full">Address<textarea name="address" rows="3"></textarea></label>
<div class="actions full"><button class="btn" type="submit">Save Patient</button><a class="btn light" href="index.php">Cancel</a></div>
</form></div>
<?php include "../includes/footer.php";?>