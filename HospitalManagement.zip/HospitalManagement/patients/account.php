<?php
require_once "../includes/db.php";
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
if (empty($_SESSION['admin'])) {
  header("Location: ../login.php");
  exit;
}
$csrfToken = $_SESSION['patient_account_csrf'] ??= bin2hex(random_bytes(32));
$patientId = (int)($_GET['id'] ?? $_POST['patient_id'] ?? 0);
$pageTitle = "Patient Account";
$message = "";
$messageType = "success";
$parseIniSize = static function (string $value): int {
  $unit = strtolower(substr(trim($value), -1));
  $multiplier = match ($unit) {
    'g' => 1024 ** 3,
    'm' => 1024 ** 2,
    'k' => 1024,
    default => 1
  };
  return (int)((float)$value * $multiplier);
};
$postLimit = $parseIniSize((string)ini_get('post_max_size'));
$maxUploadBytes = min(50 * 1024 * 1024, $parseIniSize((string)ini_get('upload_max_filesize')), max(0, $postLimit - 1024 * 1024));
$maxUploadMegabytes = number_format($maxUploadBytes / 1048576, 1);

$patientStatement = $conn->prepare("SELECT patient_id, name, age, gender, phone FROM patients WHERE patient_id = ?");
$patientStatement->bind_param("i", $patientId);
$patientStatement->execute();
$patient = $patientStatement->get_result()->fetch_assoc();
if (!$patient) {
    http_response_code(404);
    exit("Patient not found.");
}

  if (isset($_GET['view']) || isset($_GET['download'])) {
    $fileId = (int)($_GET['view'] ?? $_GET['download']);
    $fileStatement = $conn->prepare("SELECT stored_name, original_name, mime_type FROM patient_files WHERE file_id = ? AND patient_id = ?");
    $fileStatement->bind_param("ii", $fileId, $patientId);
    $fileStatement->execute();
    $file = $fileStatement->get_result()->fetch_assoc();
    $filePath = __DIR__ . "/../storage/patient_records/" . ($file['stored_name'] ?? '');
    if (!$file || !is_file($filePath)) {
      http_response_code(404);
      exit("File not found.");
    }

    $download = isset($_GET['download']);
    $safeName = str_replace(["\r", "\n", '"'], '', $file['original_name']);
    header("Content-Type: " . $file['mime_type']);
    header("Content-Length: " . filesize($filePath));
    header("Content-Disposition: " . ($download ? "attachment" : "inline") . "; filename=\"" . addcslashes($safeName, "\\") . "\"; filename*=UTF-8''" . rawurlencode($safeName));
    header("X-Content-Type-Options: nosniff");
    header("Cache-Control: private, no-store");
    readfile($filePath);
    exit;
  }

  $uploadedPath = null;
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    try {
        $action = $_POST['action'] ?? '';
      if (in_array($action, ['save_prescription', 'save_medical_record', 'upload_file'], true)
        && !hash_equals($csrfToken, (string)($_POST['csrf_token'] ?? ''))) {
        throw new RuntimeException("The form expired. Please refresh the page and try again.");
      }

      if ($action === 'save_prescription') {
        $medicine = trim((string)($_POST['medicine'] ?? ''));
        $dosage = trim((string)($_POST['dosage'] ?? ''));
        $instructions = trim((string)($_POST['instructions'] ?? ''));
        $prescriptionDate = (string)($_POST['prescription_date'] ?? '');
        $doctorId = (int)($_POST['doctor_id'] ?? 0);
        $date = DateTime::createFromFormat('Y-m-d', $prescriptionDate);
        if ($medicine === '' || strlen($medicine) > 150 || strlen($dosage) > 100 || strlen($instructions) > 255 || !$date || $date->format('Y-m-d') !== $prescriptionDate) {
          throw new RuntimeException("Enter a medicine, valid date, and details within the indicated limits.");
        }
        if ($doctorId > 0) {
          $insertPrescription = $conn->prepare("INSERT INTO prescriptions (patient_id, doctor_id, medicine, dosage, instructions, prescription_date) VALUES (?, ?, ?, ?, ?, ?)");
          $insertPrescription->bind_param("iissss", $patientId, $doctorId, $medicine, $dosage, $instructions, $prescriptionDate);
        } else {
          $insertPrescription = $conn->prepare("INSERT INTO prescriptions (patient_id, doctor_id, medicine, dosage, instructions, prescription_date) VALUES (?, NULL, ?, ?, ?, ?)");
          $insertPrescription->bind_param("issss", $patientId, $medicine, $dosage, $instructions, $prescriptionDate);
        }
        $insertPrescription->execute();
        header("Location: account.php?id=" . $patientId . "&saved=prescription");
        exit;
      }

      if ($action === 'save_medical_record') {
        $diagnosis = trim((string)($_POST['diagnosis'] ?? ''));
        $notes = trim((string)($_POST['notes'] ?? ''));
        $visitDate = (string)($_POST['visit_date'] ?? '');
        $doctorId = (int)($_POST['doctor_id'] ?? 0);
        $date = DateTime::createFromFormat('Y-m-d', $visitDate);
        if ($diagnosis === '' || strlen($diagnosis) > 255 || !$date || $date->format('Y-m-d') !== $visitDate) {
          throw new RuntimeException("Enter a diagnosis and a valid visit date.");
        }
        if ($doctorId > 0) {
          $insertRecord = $conn->prepare("INSERT INTO medical_records (patient_id, doctor_id, visit_date, diagnosis, notes) VALUES (?, ?, ?, ?, ?)");
          $insertRecord->bind_param("iisss", $patientId, $doctorId, $visitDate, $diagnosis, $notes);
        } else {
          $insertRecord = $conn->prepare("INSERT INTO medical_records (patient_id, doctor_id, visit_date, diagnosis, notes) VALUES (?, NULL, ?, ?, ?)");
          $insertRecord->bind_param("isss", $patientId, $visitDate, $diagnosis, $notes);
        }
        $insertRecord->execute();
        header("Location: account.php?id=" . $patientId . "&saved=history");
        exit;
      }

      if ($action === 'upload_file') {
        $categories = ['Lab Report', 'Scan / Imaging', 'Prescription', 'Other'];
        $category = (string)($_POST['category'] ?? '');
        $title = trim((string)($_POST['title'] ?? ''));
        $recordDate = (string)($_POST['record_date'] ?? '');
        $date = DateTime::createFromFormat('Y-m-d', $recordDate);
        $upload = $_FILES['record_file'] ?? null;
        if (!in_array($category, $categories, true) || $title === '' || strlen($title) > 150 || !$date || $date->format('Y-m-d') !== $recordDate) {
          throw new RuntimeException("Choose a record type, title, and valid record date.");
        }
        if (!$upload || $upload['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($upload['tmp_name'])) {
          throw new RuntimeException("Choose a file to upload. Check that it is within the server upload limit.");
        }
        if ((int)$upload['size'] < 1 || (int)$upload['size'] > $maxUploadBytes) {
          throw new RuntimeException("This server accepts files up to " . $maxUploadMegabytes . " MB.");
        }

        $mimeType = (new finfo(FILEINFO_MIME_TYPE))->file($upload['tmp_name']);
        $allowedTypes = [
          'application/pdf' => 'pdf',
          'image/jpeg' => 'jpg',
          'image/png' => 'png',
          'image/gif' => 'gif',
          'image/webp' => 'webp',
          'video/mp4' => 'mp4',
          'video/webm' => 'webm',
          'video/quicktime' => 'mov'
        ];
        if (!isset($allowedTypes[$mimeType])) {
          throw new RuntimeException("Upload a PDF, image, or MP4/WebM/MOV video.");
        }

        $storageDirectory = __DIR__ . "/../storage/patient_records";
        if (!is_dir($storageDirectory) && !mkdir($storageDirectory, 0750, true) && !is_dir($storageDirectory)) {
          throw new RuntimeException("The private records folder could not be created.");
        }
        $originalName = basename(str_replace('\\', '/', (string)$upload['name']));
        $originalName = substr($originalName, 0, 255);
        $storedName = bin2hex(random_bytes(24)) . '.' . $allowedTypes[$mimeType];
        $uploadedPath = $storageDirectory . '/' . $storedName;
        if (!move_uploaded_file($upload['tmp_name'], $uploadedPath)) {
          throw new RuntimeException("The uploaded file could not be stored.");
        }
        $insertFile = $conn->prepare("INSERT INTO patient_files (patient_id, category, title, original_name, stored_name, mime_type, file_size, record_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $fileSize = (int)$upload['size'];
        $insertFile->bind_param("isssssis", $patientId, $category, $title, $originalName, $storedName, $mimeType, $fileSize, $recordDate);
        $insertFile->execute();
        $uploadedPath = null;
        header("Location: account.php?id=" . $patientId . "&saved=file");
        exit;
      }

        if ($action === 'allocate_room') {
            $roomId = (int)($_POST['room_id'] ?? 0);
            $admissionDate = $_POST['admission_date'] ?? date('Y-m-d');
            $date = DateTime::createFromFormat('Y-m-d', $admissionDate);
            if ($roomId < 1 || !$date || $date->format('Y-m-d') !== $admissionDate) {
                throw new RuntimeException("Choose a valid room and admission date.");
            }

            $conn->begin_transaction();
            $activeStatement = $conn->prepare("SELECT admission_id FROM admissions WHERE patient_id = ? AND status IN ('Admitted', 'Active') FOR UPDATE");
            $activeStatement->bind_param("i", $patientId);
            $activeStatement->execute();
            if ($activeStatement->get_result()->num_rows) {
                throw new RuntimeException("This patient already has an active room allocation.");
            }

            $roomStatement = $conn->prepare("SELECT room_id FROM rooms WHERE room_id = ? AND is_occupied = 0 FOR UPDATE");
            $roomStatement->bind_param("i", $roomId);
            $roomStatement->execute();
            if (!$roomStatement->get_result()->fetch_assoc()) {
                throw new RuntimeException("That room is no longer available. Refresh and choose another room.");
            }

            $status = "Admitted";
            $insertAdmission = $conn->prepare("INSERT INTO admissions (patient_id, room_id, admission_date, discharge_date, status) VALUES (?, ?, ?, NULL, ?)");
            $insertAdmission->bind_param("iiss", $patientId, $roomId, $admissionDate, $status);
            $insertAdmission->execute();
            $updateRoom = $conn->prepare("UPDATE rooms SET is_occupied = 1 WHERE room_id = ?");
            $updateRoom->bind_param("i", $roomId);
            $updateRoom->execute();
            $conn->commit();
            header("Location: account.php?id=" . $patientId . "&saved=room");
            exit;
        }

        if ($action === 'discharge') {
            $admissionId = (int)($_POST['admission_id'] ?? 0);
            $conn->begin_transaction();
            $admissionStatement = $conn->prepare("SELECT room_id FROM admissions WHERE admission_id = ? AND patient_id = ? AND status IN ('Admitted', 'Active') FOR UPDATE");
            $admissionStatement->bind_param("ii", $admissionId, $patientId);
            $admissionStatement->execute();
            $admission = $admissionStatement->get_result()->fetch_assoc();
            if (!$admission) {
                throw new RuntimeException("The active admission could not be found.");
            }

            $dischargeStatement = $conn->prepare("UPDATE admissions SET discharge_date = CURDATE(), status = 'Discharged' WHERE admission_id = ? AND patient_id = ?");
            $dischargeStatement->bind_param("ii", $admissionId, $patientId);
            $dischargeStatement->execute();
            if ($admission['room_id'] !== null) {
                $releaseRoom = $conn->prepare("UPDATE rooms SET is_occupied = 0 WHERE room_id = ?");
                $releaseRoom->bind_param("i", $admission['room_id']);
                $releaseRoom->execute();
            }
            $conn->commit();
            header("Location: account.php?id=" . $patientId . "&saved=discharge");
            exit;
        }

        if ($action === 'create_bill') {
            $admissionId = (int)($_POST['admission_id'] ?? 0);
            $doctorCharge = filter_var($_POST['doctor_charge'] ?? 0, FILTER_VALIDATE_FLOAT);
            $paymentStatus = $_POST['payment_status'] ?? 'Pending';
            $allowedStatuses = ['Pending', 'Paid', 'Partial'];
            if ($doctorCharge === false || $doctorCharge < 0 || !in_array($paymentStatus, $allowedStatuses, true)) {
                throw new RuntimeException("Enter a valid doctor charge and payment status.");
            }

            $roomCharge = 0.0;
            $roomDays = 0;
            $roomRate = 0.0;
            $roomDescription = '';
            if ($admissionId > 0) {
              $stayStatement = $conn->prepare("SELECT a.admission_id, a.admission_date, a.discharge_date, r.room_type, r.cost_per_day FROM admissions a LEFT JOIN rooms r ON r.room_id = a.room_id WHERE a.admission_id = ? AND a.patient_id = ?");
                $stayStatement->bind_param("ii", $admissionId, $patientId);
                $stayStatement->execute();
                $stay = $stayStatement->get_result()->fetch_assoc();
                if (!$stay) {
                    throw new RuntimeException("Choose an admission belonging to this patient.");
                }
                $endDate = $stay['discharge_date'] ?: date('Y-m-d');
                $stayDays = max(1, (int)((strtotime($endDate) - strtotime($stay['admission_date'])) / 86400));
                $roomRate = (float)($stay['cost_per_day'] ?? 0);
                $grossRoomCharge = $roomRate * $stayDays;
                $previousRoomStatement = $conn->prepare("SELECT COALESCE(SUM(room_charge), 0) billed FROM bills WHERE admission_id = ?");
                $previousRoomStatement->bind_param("i", $admissionId);
                $previousRoomStatement->execute();
                $previousRoomCharge = (float)$previousRoomStatement->get_result()->fetch_assoc()['billed'];
                $roomCharge = max(0, $grossRoomCharge - $previousRoomCharge);
                $roomDays = $roomRate > 0 ? (int)ceil($roomCharge / $roomRate) : 0;
                if ($roomCharge > 0) {
                  $roomDescription = ($stay['room_type'] ?? 'Room') . ' rent, ' . $roomDays . ' day(s), ' . $stay['admission_date'] . ' to ' . $endDate;
                }
            }

            $items = json_decode($_POST['items_json'] ?? '[]', true);
            if (!is_array($items)) {
                throw new RuntimeException("The bill details were not valid. Please review the line items.");
            }
            $cleanItems = [];
            $otherCharge = 0.0;
            foreach ($items as $item) {
                if (!is_array($item)) continue;
                $type = in_array($item['type'] ?? '', ['Medicine', 'Treatment'], true) ? $item['type'] : '';
                $description = trim((string)($item['description'] ?? ''));
                $quantity = filter_var($item['quantity'] ?? 0, FILTER_VALIDATE_FLOAT);
                $unitPrice = filter_var($item['unit_price'] ?? 0, FILTER_VALIDATE_FLOAT);
                if ($description === '' && $type === '') continue;
                if ($type === '' || $description === '' || $quantity === false || $quantity <= 0 || $unitPrice === false || $unitPrice < 0) {
                    throw new RuntimeException("Each medicine or treatment needs a description, positive quantity, and valid unit price.");
                }
                $quantity = round((float)$quantity, 2);
                $unitPrice = round((float)$unitPrice, 2);
                $lineTotal = round($quantity * $unitPrice, 2);
                $otherCharge += $lineTotal;
                $cleanItems[] = [$type, substr($description, 0, 200), $quantity, $unitPrice, $lineTotal];
            }

              if ($roomCharge > 0) {
                array_unshift($cleanItems, ['Room rent', substr($roomDescription, 0, 200), $roomDays, $roomRate, $roomCharge]);
              }

            if ($admissionId < 1 && !$cleanItems && (float)$doctorCharge <= 0) {
                throw new RuntimeException("Add a room stay, doctor charge, medicine, or treatment before creating a bill.");
            }

            $totalAmount = round((float)$doctorCharge + $roomCharge + $otherCharge, 2);
            $columns = ['patient_id', 'admission_id', 'doctor_charge', 'room_charge'];
            $values = [$patientId, $admissionId ?: null, (float)$doctorCharge, $roomCharge];
            $types = 'iidd';
            $billColumns = $conn->query("SHOW COLUMNS FROM bills");
            $availableColumns = [];
            while ($column = $billColumns->fetch_assoc()) $availableColumns[] = $column['Field'];
            if (in_array('other_charge', $availableColumns, true)) {
                $columns[] = 'other_charge';
                $values[] = $otherCharge;
                $types .= 'd';
            }
            $columns[] = 'total_amount';
            $values[] = $totalAmount;
            $types .= 'd';
            $columns[] = 'payment_status';
            $values[] = $paymentStatus;
            $types .= 's';
            $billDateSql = '';
            if (in_array('bill_date', $availableColumns, true)) {
                $columns[] = 'bill_date';
                $billDateSql = ', CURDATE()';
            }

            $conn->begin_transaction();
            $placeholders = implode(', ', array_fill(0, count($values), '?')) . $billDateSql;
            $insertBill = $conn->prepare("INSERT INTO bills (" . implode(', ', $columns) . ") VALUES (" . $placeholders . ")");
            $bindArguments = [$types];
            foreach ($values as $index => &$value) $bindArguments[] = &$value;
            call_user_func_array([$insertBill, 'bind_param'], $bindArguments);
            $insertBill->execute();
            $billId = $conn->insert_id;

            if ($cleanItems) {
                $insertItem = $conn->prepare("INSERT INTO bill_items (bill_id, item_type, description, quantity, unit_price, line_total) VALUES (?, ?, ?, ?, ?, ?)");
                foreach ($cleanItems as [$type, $description, $quantity, $unitPrice, $lineTotal]) {
                    $insertItem->bind_param("issddd", $billId, $type, $description, $quantity, $unitPrice, $lineTotal);
                    $insertItem->execute();
                }
            }
            $conn->commit();
            header("Location: account.php?id=" . $patientId . "&saved=bill");
            exit;
        }
    } catch (Throwable $error) {
        try { $conn->rollback(); } catch (Throwable $ignored) {}
      if ($uploadedPath && is_file($uploadedPath)) unlink($uploadedPath);
        $message = $error instanceof RuntimeException ? $error->getMessage() : "The change could not be saved. Please check the details and try again.";
        $messageType = "error";
    }
}

if (isset($_GET['saved'])) {
    $message = match ($_GET['saved']) {
        'room' => 'Room allocated to this patient.',
        'discharge' => 'Patient discharged and room released.',
        'bill' => 'Bill saved to this patient account.',
        'prescription' => 'Prescription added to this patient account.',
        'history' => 'Medical history added to this patient account.',
        'file' => 'Record uploaded to this patient account.',
        default => ''
    };
}

$roomResult = $conn->query("SELECT room_id, room_type, cost_per_day FROM rooms WHERE is_occupied = 0 ORDER BY cost_per_day, room_type");
$activeStatement = $conn->prepare("SELECT a.*, r.room_type, r.cost_per_day, GREATEST(1, DATEDIFF(COALESCE(a.discharge_date, CURDATE()), a.admission_date)) stay_days FROM admissions a LEFT JOIN rooms r ON r.room_id = a.room_id WHERE a.patient_id = ? AND a.status IN ('Admitted', 'Active') ORDER BY a.admission_id DESC LIMIT 1");
$activeStatement->bind_param("i", $patientId);
$activeStatement->execute();
$activeAdmission = $activeStatement->get_result()->fetch_assoc();
$admissionStatement = $conn->prepare("SELECT a.admission_id, a.admission_date, a.discharge_date, a.status, r.room_type FROM admissions a LEFT JOIN rooms r ON r.room_id = a.room_id WHERE a.patient_id = ? ORDER BY a.admission_id DESC");
$admissionStatement->bind_param("i", $patientId);
$admissionStatement->execute();
$admissions = $admissionStatement->get_result();
$billableStatement = $conn->prepare("SELECT a.admission_id, a.admission_date, a.discharge_date, a.status, r.room_type FROM admissions a LEFT JOIN rooms r ON r.room_id = a.room_id WHERE a.patient_id = ? ORDER BY a.admission_id DESC");
$billableStatement->bind_param("i", $patientId);
$billableStatement->execute();
$billableAdmissions = $billableStatement->get_result();
$billStatement = $conn->prepare("SELECT b.*, a.admission_date, a.discharge_date, r.room_type, GREATEST(1, DATEDIFF(COALESCE(a.discharge_date, CURDATE()), a.admission_date)) stay_days, CASE WHEN a.admission_id IS NOT NULL THEN b.room_charge / GREATEST(1, DATEDIFF(COALESCE(a.discharge_date, CURDATE()), a.admission_date)) ELSE 0 END billed_daily_rate, GROUP_CONCAT(CONCAT(bi.item_type, ': ', bi.description, ' x ', bi.quantity, ' = Rs ', FORMAT(bi.line_total, 2)) ORDER BY bi.bill_item_id SEPARATOR ' | ') item_details FROM bills b LEFT JOIN admissions a ON a.admission_id = b.admission_id LEFT JOIN rooms r ON r.room_id = a.room_id LEFT JOIN bill_items bi ON bi.bill_id = b.bill_id WHERE b.patient_id = ? GROUP BY b.bill_id ORDER BY b.bill_id DESC");
$billStatement->bind_param("i", $patientId);
$billStatement->execute();
$bills = $billStatement->get_result();
$historyStatement = $conn->prepare("SELECT mr.*, d.name doctor_name FROM medical_records mr LEFT JOIN doctors d ON d.doctor_id = mr.doctor_id WHERE mr.patient_id = ? ORDER BY mr.visit_date DESC, mr.record_id DESC");
$historyStatement->bind_param("i", $patientId);
$historyStatement->execute();
$medicalRecords = $historyStatement->get_result();
$prescriptionStatement = $conn->prepare("SELECT pr.*, d.name doctor_name FROM prescriptions pr LEFT JOIN doctors d ON d.doctor_id = pr.doctor_id WHERE pr.patient_id = ? ORDER BY pr.prescription_date DESC, pr.prescription_id DESC");
$prescriptionStatement->bind_param("i", $patientId);
$prescriptionStatement->execute();
$prescriptions = $prescriptionStatement->get_result();
$fileStatement = $conn->prepare("SELECT * FROM patient_files WHERE patient_id = ? ORDER BY record_date DESC, file_id DESC");
$fileStatement->bind_param("i", $patientId);
$fileStatement->execute();
$patientFiles = $fileStatement->get_result();
$doctorOptions = $conn->query("SELECT doctor_id, name FROM doctors ORDER BY name");
$doctorList = [];
while ($doctorOption = $doctorOptions->fetch_assoc()) $doctorList[] = $doctorOption;

include "../includes/header.php";
?>
<div class="page-head"><div><h1><?= htmlspecialchars($patient['name']) ?>'s Account</h1><p>Patient ID P<?= str_pad($patientId, 3, '0', STR_PAD_LEFT) ?> · <?= (int)$patient['age'] ?> years · <?= htmlspecialchars($patient['gender']) ?></p></div><a class="btn light" href="index.php">Back to Patients</a></div>
<?php if ($message): ?><div class="account-message <?= htmlspecialchars($messageType) ?>"><?= htmlspecialchars($message) ?></div><?php endif; ?>

<div class="account-grid">
  <section class="card panel">
    <h2>Room Allocation</h2>
    <?php if ($activeAdmission): ?>
      <div class="account-summary"><b><?= htmlspecialchars($activeAdmission['room_type'] ?? 'Room') ?></b><span>₹<?= number_format((float)$activeAdmission['cost_per_day'], 2) ?> / day</span><span>Admitted <?= htmlspecialchars($activeAdmission['admission_date']) ?></span><span>Current stay: <?= (int)$activeAdmission['stay_days'] ?> day(s)</span><b>Current room total: ₹<?= number_format((float)$activeAdmission['cost_per_day'] * (int)$activeAdmission['stay_days'], 2) ?></b></div>
      <form method="post" class="actions"><input type="hidden" name="patient_id" value="<?= $patientId ?>"><input type="hidden" name="admission_id" value="<?= (int)$activeAdmission['admission_id'] ?>"><button class="btn danger" type="submit" name="action" value="discharge">Discharge patient</button></form>
    <?php else: ?>
      <form method="post" class="form account-form">
        <input type="hidden" name="patient_id" value="<?= $patientId ?>"><input type="hidden" name="action" value="allocate_room">
        <label>Available room<select name="room_id" required><option value="">Select room</option><?php while ($room = $roomResult->fetch_assoc()): ?><option value="<?= (int)$room['room_id'] ?>"><?= htmlspecialchars($room['room_type']) ?> · ₹<?= number_format((float)$room['cost_per_day'], 2) ?>/day</option><?php endwhile; ?></select></label>
        <label>Admission date<input type="date" name="admission_date" value="<?= date('Y-m-d') ?>" required></label>
        <div class="actions full"><button class="btn" type="submit">Allocate room</button></div>
      </form>
      <?php if (!$roomResult->num_rows): ?><p class="settings-note">No rooms are currently available.</p><?php endif; ?>
    <?php endif; ?>
  </section>

  <section class="card panel">
    <h2>Create Bill</h2>
    <form method="post" class="form account-form" id="patientBillForm">
      <input type="hidden" name="patient_id" value="<?= $patientId ?>"><input type="hidden" name="action" value="create_bill"><input type="hidden" name="items_json" id="billItemsJson" value="[]">
      <label class="full">Room stay<select name="admission_id" id="billAdmission"><option value="0">No room stay</option><?php
        while ($option = $billableAdmissions->fetch_assoc()):
      ?><option value="<?= (int)$option['admission_id'] ?>"><?= htmlspecialchars(($option['room_type'] ?? 'No room') . ' · ' . $option['admission_date'] . ' to ' . ($option['discharge_date'] ?: 'today') . ' · ' . $option['status']) ?></option><?php endwhile; ?></select></label>
      <label>Doctor charge<input type="number" name="doctor_charge" min="0" step="0.01" value="0"></label>
      <label>Payment status<select name="payment_status"><option>Pending</option><option>Partial</option><option>Paid</option></select></label>
      <div class="full">
        <div class="item-heading"><b>Medicine and treatment charges</b><button class="btn light" id="addBillItem" type="button">+ Add item</button></div>
        <div id="billItems" class="bill-items"></div>
      </div>
      <div class="full bill-preview" id="billPreview">Select a room stay or add a bill item.</div>
      <div class="actions full"><button class="btn" type="submit">Save patient bill</button></div>
    </form>
  </section>
</div>

<section class="card panel account-section">
  <h2>Admissions and Room History</h2>
  <div class="table-wrap"><table class="table"><thead><tr><th>Admission</th><th>Room</th><th>Admitted</th><th>Discharged</th><th>Status</th></tr></thead><tbody>
  <?php if ($admissions->num_rows): while ($admission = $admissions->fetch_assoc()): ?><tr><td>ADM-<?= (int)$admission['admission_id'] ?></td><td><?= htmlspecialchars($admission['room_type'] ?? '—') ?></td><td><?= htmlspecialchars($admission['admission_date']) ?></td><td><?= htmlspecialchars($admission['discharge_date'] ?? '—') ?></td><td><?= htmlspecialchars($admission['status']) ?></td></tr><?php endwhile; else: ?><tr><td colspan="5">No room allocations recorded.</td></tr><?php endif; ?>
  </tbody></table></div>
</section>

<section class="card panel account-section">
  <h2>Patient Bills</h2>
  <div class="table-wrap"><table class="table"><thead><tr><th>Invoice</th><th>Stay</th><th>Doctor</th><th>Room rent</th><th>Medicines / treatments</th><th>Total</th><th>Status</th></tr></thead><tbody>
  <?php if ($bills->num_rows): while ($bill = $bills->fetch_assoc()): ?><tr><td>INV-<?= str_pad($bill['bill_id'], 3, '0', STR_PAD_LEFT) ?></td><td><?php if ($bill['admission_date']): ?><?= (int)$bill['stay_days'] ?> day(s) · <?= htmlspecialchars($bill['room_type'] ?? 'Room') ?><small class="table-subtext"><?= htmlspecialchars($bill['admission_date'] . ' to ' . ($bill['discharge_date'] ?: 'today')) ?></small><?php else: ?>—<?php endif; ?></td><td>₹<?= number_format((float)$bill['doctor_charge'], 2) ?></td><td>₹<?= number_format((float)$bill['room_charge'], 2) ?><?php if ($bill['admission_date']): ?><small class="table-subtext"><?= (int)$bill['stay_days'] ?> × ₹<?= number_format((float)$bill['billed_daily_rate'], 2) ?>/day</small><?php endif; ?></td><td><?= htmlspecialchars($bill['item_details'] ?: ((float)$bill['other_charge'] > 0 ? 'Other charges: ₹' . number_format((float)$bill['other_charge'], 2) : '—')) ?></td><td><b>₹<?= number_format((float)$bill['total_amount'], 2) ?></b></td><td><?= htmlspecialchars($bill['payment_status']) ?></td></tr><?php endwhile; else: ?><tr><td colspan="7">No bills recorded for this patient.</td></tr><?php endif; ?>
  </tbody></table></div>
</section>

<section class="card panel account-section">
  <h2>Past Medical History</h2>
  <form method="post" class="form account-form clinical-entry-form">
    <input type="hidden" name="patient_id" value="<?= $patientId ?>"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>"><input type="hidden" name="action" value="save_medical_record">
    <label>Visit date<input type="date" name="visit_date" value="<?= date('Y-m-d') ?>" required></label>
    <label>Doctor<select name="doctor_id"><option value="0">Not specified</option><?php foreach ($doctorList as $doctor): ?><option value="<?= (int)$doctor['doctor_id'] ?>"><?= htmlspecialchars($doctor['name']) ?></option><?php endforeach; ?></select></label>
    <label>Diagnosis<input name="diagnosis" maxlength="255" required></label>
    <label>Notes<input name="notes" placeholder="Symptoms, treatment, or follow-up"></label>
    <div class="actions full"><button class="btn" type="submit">Add history record</button></div>
  </form>
  <div class="table-wrap"><table class="table"><thead><tr><th>Date</th><th>Diagnosis</th><th>Doctor</th><th>Notes</th></tr></thead><tbody>
  <?php if ($medicalRecords->num_rows): while ($record = $medicalRecords->fetch_assoc()): ?><tr><td><?= htmlspecialchars($record['visit_date']) ?></td><td><?= htmlspecialchars($record['diagnosis']) ?></td><td><?= htmlspecialchars($record['doctor_name'] ?? '—') ?></td><td><?= nl2br(htmlspecialchars($record['notes'] ?? '—')) ?></td></tr><?php endwhile; else: ?><tr><td colspan="4">No medical history recorded.</td></tr><?php endif; ?>
  </tbody></table></div>
</section>

<section class="card panel account-section">
  <h2>Prescriptions and Medicines</h2>
  <form method="post" class="form account-form clinical-entry-form">
    <input type="hidden" name="patient_id" value="<?= $patientId ?>"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>"><input type="hidden" name="action" value="save_prescription">
    <label>Date<input type="date" name="prescription_date" value="<?= date('Y-m-d') ?>" required></label>
    <label>Doctor<select name="doctor_id"><option value="0">Not specified</option><?php foreach ($doctorList as $doctor): ?><option value="<?= (int)$doctor['doctor_id'] ?>"><?= htmlspecialchars($doctor['name']) ?></option><?php endforeach; ?></select></label>
    <label>Medicine<input name="medicine" maxlength="150" required></label>
    <label>Dosage<input name="dosage" maxlength="100" placeholder="e.g. 1 tablet twice daily"></label>
    <label class="full">Instructions<input name="instructions" maxlength="255" placeholder="Timing, duration, or other directions"></label>
    <div class="actions full"><button class="btn" type="submit">Add prescription</button></div>
  </form>
  <div class="table-wrap"><table class="table"><thead><tr><th>Date</th><th>Medicine</th><th>Dosage</th><th>Instructions</th><th>Doctor</th></tr></thead><tbody>
  <?php if ($prescriptions->num_rows): while ($prescription = $prescriptions->fetch_assoc()): ?><tr><td><?= htmlspecialchars($prescription['prescription_date']) ?></td><td><?= htmlspecialchars($prescription['medicine']) ?></td><td><?= htmlspecialchars($prescription['dosage'] ?? '—') ?></td><td><?= htmlspecialchars($prescription['instructions'] ?? '—') ?></td><td><?= htmlspecialchars($prescription['doctor_name'] ?? '—') ?></td></tr><?php endwhile; else: ?><tr><td colspan="5">No prescriptions recorded.</td></tr><?php endif; ?>
  </tbody></table></div>
</section>

<section class="card panel account-section">
  <h2>Lab Reports, Scans and Files</h2>
  <form method="post" enctype="multipart/form-data" class="form account-form clinical-entry-form">
    <input type="hidden" name="patient_id" value="<?= $patientId ?>"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>"><input type="hidden" name="action" value="upload_file">
    <label>Record type<select name="category" required><option>Lab Report</option><option>Scan / Imaging</option><option>Prescription</option><option>Other</option></select></label>
    <label>Record date<input type="date" name="record_date" value="<?= date('Y-m-d') ?>" required></label>
    <label>Title<input name="title" maxlength="150" placeholder="e.g. Blood panel, chest X-ray" required></label>
    <label>File<input type="file" name="record_file" accept=".pdf,.jpg,.jpeg,.png,.gif,.webp,.mp4,.webm,.mov,application/pdf,image/*,video/mp4,video/webm,video/quicktime" required></label>
    <p class="upload-note full">PDF, image, or MP4/WebM/MOV video · maximum <?= htmlspecialchars($maxUploadMegabytes) ?> MB</p>
    <div class="actions full"><button class="btn" type="submit">Upload patient record</button></div>
  </form>
  <div class="table-wrap"><table class="table patient-files-table"><thead><tr><th>Record</th><th>Type</th><th>Date</th><th>Preview</th><th>File</th><th></th></tr></thead><tbody>
  <?php if ($patientFiles->num_rows): while ($file = $patientFiles->fetch_assoc()): $viewUrl = 'account.php?id=' . $patientId . '&view=' . (int)$file['file_id']; $downloadUrl = 'account.php?id=' . $patientId . '&download=' . (int)$file['file_id']; ?><tr>
    <td><?= htmlspecialchars($file['title']) ?></td><td><?= htmlspecialchars($file['category']) ?></td><td><?= htmlspecialchars($file['record_date']) ?></td>
    <td class="record-preview"><?php if (str_starts_with($file['mime_type'], 'image/')): ?><a href="<?= htmlspecialchars($viewUrl) ?>" target="_blank" rel="noopener"><img class="record-thumb" src="<?= htmlspecialchars($viewUrl) ?>" alt="<?= htmlspecialchars($file['title']) ?>"></a><?php elseif (str_starts_with($file['mime_type'], 'video/')): ?><video controls preload="none" src="<?= htmlspecialchars($viewUrl) ?>"></video><?php elseif ($file['mime_type'] === 'application/pdf'): ?><a href="<?= htmlspecialchars($viewUrl) ?>" target="_blank" rel="noopener">Open PDF</a><?php else: ?>—<?php endif; ?></td>
    <td><?= htmlspecialchars($file['original_name']) ?><small class="table-subtext"><?= number_format((int)$file['file_size'] / 1048576, 2) ?> MB</small></td><td><a class="btn light file-download" href="<?= htmlspecialchars($downloadUrl) ?>">Download</a></td>
  </tr><?php endwhile; else: ?><tr><td colspan="6">No lab reports or files uploaded.</td></tr><?php endif; ?>
  </tbody></table></div>
</section>

<script>
(() => {
  const form = document.getElementById('patientBillForm');
  const itemsHost = document.getElementById('billItems');
  const addButton = document.getElementById('addBillItem');
  const itemsInput = document.getElementById('billItemsJson');
  const preview = document.getElementById('billPreview');
  const admissionSelect = document.getElementById('billAdmission');

  const addItem = () => {
    const row = document.createElement('div');
    row.className = 'bill-item-row';
    row.innerHTML = '<select aria-label="Charge type"><option>Medicine</option><option>Treatment</option></select><input aria-label="Description" placeholder="Medicine or treatment" maxlength="200"><input aria-label="Quantity" type="number" min="0.01" step="0.01" value="1"><input aria-label="Unit price" type="number" min="0" step="0.01" value="0"><button type="button" class="icon-btn remove-bill-item" aria-label="Remove item">×</button>';
    itemsHost.append(row);
    row.addEventListener('input', updatePreview);
    row.querySelector('.remove-bill-item').addEventListener('click', () => { row.remove(); updatePreview(); });
    updatePreview();
  };

  const updatePreview = () => {
    const items = [...itemsHost.querySelectorAll('.bill-item-row')].map(row => ({
      type: row.children[0].value,
      description: row.children[1].value.trim(),
      quantity: Number(row.children[2].value || 0),
      unit_price: Number(row.children[3].value || 0)
    })).filter(item => item.description);
    itemsInput.value = JSON.stringify(items);
    const itemTotal = items.reduce((total, item) => total + item.quantity * item.unit_price, 0);
    const doctor = Number(form.elements.doctor_charge.value || 0);
    preview.textContent = `Doctor ₹${doctor.toFixed(2)} · Room rent calculated from stay · Medicines/treatments ₹${itemTotal.toFixed(2)}`;
  };

  addButton.addEventListener('click', addItem);
  form.elements.doctor_charge.addEventListener('input', updatePreview);
  admissionSelect.addEventListener('change', updatePreview);
  form.addEventListener('submit', () => { updatePreview(); });
  addItem();
})();
</script>
<?php include "../includes/footer.php"; ?>