<?php
require_once "../includes/db.php";
$pageTitle = "Billing & Payments";
$search = trim($_GET['q'] ?? '');
$total = (float)($conn->query("SELECT COALESCE(SUM(total_amount), 0) c FROM bills")->fetch_assoc()['c'] ?? 0);
$billCount = (int)($conn->query("SELECT COUNT(*) c FROM bills")->fetch_assoc()['c'] ?? 0);
$sql = "SELECT b.*, p.patient_id, p.name patient_name, a.admission_date, a.discharge_date, r.room_type,
  GREATEST(1, DATEDIFF(COALESCE(a.discharge_date, CURDATE()), a.admission_date)) stay_days,
  CASE WHEN a.admission_id IS NOT NULL THEN b.room_charge / GREATEST(1, DATEDIFF(COALESCE(a.discharge_date, CURDATE()), a.admission_date)) ELSE 0 END billed_daily_rate,
        GROUP_CONCAT(CONCAT(bi.item_type, ': ', bi.description, ' x ', bi.quantity, ' = Rs ', FORMAT(bi.line_total, 2)) ORDER BY bi.bill_item_id SEPARATOR ' | ') item_details
        FROM bills b
        JOIN patients p ON p.patient_id = b.patient_id
        LEFT JOIN admissions a ON a.admission_id = b.admission_id
        LEFT JOIN rooms r ON r.room_id = a.room_id
        LEFT JOIN bill_items bi ON bi.bill_id = b.bill_id";
if ($search !== '') {
  if (preg_match('/^P?(\d+)$/i', $search, $matches)) {
    $sql .= " WHERE p.name LIKE ? OR p.patient_id = ?";
  } else {
    $sql .= " WHERE p.name LIKE ?";
  }
}
$sql .= " GROUP BY b.bill_id ORDER BY b.bill_id DESC";
$statement = $conn->prepare($sql);
if ($search !== '') {
    $query = "%" . $search . "%";
  if (isset($matches[1])) {
    $searchId = (int)$matches[1];
    $statement->bind_param("si", $query, $searchId);
  } else {
    $statement->bind_param("s", $query);
  }
}
$statement->execute();
$bills = $statement->get_result();
include "../includes/header.php";
?>
<div class="page-head"><div><h1>Billing & Payments</h1><p>Find a patient's invoices and review every recorded charge.</p></div></div>
<div class="stats"><div class="card stat"><div><div class="stat-icon">₹</div><h3>₹<?= number_format($total, 2) ?></h3><p>Total billed</p></div></div><div class="card stat"><div><div class="stat-icon">▣</div><h3><?= $billCount ?></h3><p>Total invoices</p></div></div></div>

<section class="card panel billing-panel">
  <form method="get" class="billing-search"><label for="billingSearch">Patient</label><input id="billingSearch" name="q" value="<?= htmlspecialchars($search) ?>" placeholder="Type patient name or ID (e.g. 12 or P012)"><button class="btn" type="submit">Search</button><?php if ($search !== ''): ?><a class="btn light" href="index.php">Clear</a><?php endif; ?></form>
  <div class="table-wrap"><table class="table billing-table"><thead><tr><th>Invoice</th><th>Patient</th><th>Stay / room</th><th>Doctor</th><th>Room rent</th><th>Medicines & treatments</th><th>Total</th><th>Payment</th><th></th></tr></thead><tbody>
  <?php if ($bills->num_rows): while ($bill = $bills->fetch_assoc()): ?>
    <tr>
      <td>INV-<?= str_pad($bill['bill_id'], 3, '0', STR_PAD_LEFT) ?></td>
      <td><b><?= htmlspecialchars($bill['patient_name']) ?></b><small class="table-subtext">ID P<?= str_pad($bill['patient_id'], 3, '0', STR_PAD_LEFT) ?></small></td>
      <td><?php if ($bill['admission_date']): ?><?= (int)$bill['stay_days'] ?> day(s) · <?= htmlspecialchars($bill['room_type'] ?? 'Room') ?><small class="table-subtext"><?= htmlspecialchars($bill['admission_date']) ?> to <?= htmlspecialchars($bill['discharge_date'] ?: 'today') ?></small><?php else: ?>—<?php endif; ?></td>
      <td>₹<?= number_format((float)$bill['doctor_charge'], 2) ?></td>
      <td>₹<?= number_format((float)$bill['room_charge'], 2) ?><?php if ($bill['admission_date']): ?><small class="table-subtext"><?= (int)$bill['stay_days'] ?> × ₹<?= number_format((float)$bill['billed_daily_rate'], 2) ?>/day</small><?php endif; ?></td>
      <td class="bill-detail"><?= htmlspecialchars($bill['item_details'] ?: ((float)$bill['other_charge'] > 0 ? 'Other charges: ₹' . number_format((float)$bill['other_charge'], 2) : '—')) ?></td>
      <td><b>₹<?= number_format((float)$bill['total_amount'], 2) ?></b></td>
      <td><span class="badge"><?= htmlspecialchars($bill['payment_status']) ?></span></td>
      <td><a class="btn light" href="../patients/account.php?id=<?= (int)$bill['patient_id'] ?>">Account</a></td>
    </tr>
  <?php endwhile; else: ?><tr><td colspan="9"><?= $search !== '' ? 'No invoices found for that patient.' : 'No bills have been recorded yet.' ?></td></tr><?php endif; ?>
  </tbody></table></div>
</section>
<?php include "../includes/footer.php"; ?>