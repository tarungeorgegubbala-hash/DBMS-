<?php $pageTitle="Settings"; include "../includes/header.php"; ?>
<div class="page-head"><div><h1>Settings</h1><p>Personalize how this workspace looks and behaves.</p></div></div>
<div class="card panel settings-panel">
	<h2>Preferences</h2>
	<div class="setting-list">
		<label class="setting-row" for="darkModeSetting">
			<span><b>Dark mode</b><small>Use a low-light color scheme across the dashboard.</small></span>
			<span class="setting-toggle"><input id="darkModeSetting" type="checkbox"><span aria-hidden="true"></span></span>
		</label>
		<label class="setting-row" for="notificationsSetting">
			<span><b>In-app notifications</b><small>Show notification updates from the header control.</small></span>
			<span class="setting-toggle"><input id="notificationsSetting" type="checkbox" data-preference="notifications-enabled"><span aria-hidden="true"></span></span>
		</label>
		<label class="setting-row" for="compactModeSetting">
			<span><b>Compact tables</b><small>Reduce row spacing on data tables and recent activity.</small></span>
			<span class="setting-toggle"><input id="compactModeSetting" type="checkbox" data-preference="compact-mode"><span aria-hidden="true"></span></span>
		</label>
		<label class="setting-row" for="reducedMotionSetting">
			<span><b>Reduce motion</b><small>Disable interface transitions and animations.</small></span>
			<span class="setting-toggle"><input id="reducedMotionSetting" type="checkbox" data-preference="reduced-motion"><span aria-hidden="true"></span></span>
		</label>
	</div>
	<p class="settings-note">Preferences are saved in this browser and do not change hospital records.</p>
</div>
<?php include "../includes/footer.php";?>