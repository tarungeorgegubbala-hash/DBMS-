HOSPITAL MANAGEMENT SYSTEM
================================

1. Keep your existing D:\HospitalManagement\config\db.php/database.php connection.
2. Copy the folders/files from this package into D:\HospitalManagement.
3. If you already have config/database.php, keep the version whose password matches your working connection.
4. Start Apache in XAMPP. Keep your existing MySQL80 service running.
5. Open:
   http://localhost/hospital/

Main pages:
Dashboard: /hospital/
Patients: /hospital/patients/
Doctors: /hospital/doctors/
Appointments: /hospital/appointments/
Billing: /hospital/billing/
Medical Records: /hospital/admissions/
Settings: /hospital/settings/

This design follows the requested deep-green premium healthcare dashboard direction while keeping the code simple enough to explain in a DBMS viva.
