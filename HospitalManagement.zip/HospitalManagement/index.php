<?php
require_once __DIR__ . "/includes/db.php";

$pageTitle = "Dashboard";

$patients = (int)($conn->query("SELECT COUNT(*) c FROM patients")->fetch_assoc()['c'] ?? 0);
$doctors = (int)($conn->query("SELECT COUNT(*) c FROM doctors")->fetch_assoc()['c'] ?? 0);
$appointments = (int)($conn->query("SELECT COUNT(*) c FROM appointments WHERE appointment_date = CURDATE()")->fetch_assoc()['c'] ?? 0);
$bills = (float)($conn->query("SELECT COALESCE(SUM(total_amount),0) c FROM bills")->fetch_assoc()['c'] ?? 0);

$weekDates = [];
$weekCounts = array_fill(0, 7, 0);
for ($offset = 6; $offset >= 0; $offset--) {
    $weekDates[] = date('Y-m-d', strtotime("-$offset days"));
}
$weekResult = $conn->query("SELECT appointment_date, COUNT(*) total FROM appointments WHERE appointment_date >= DATE_SUB(CURDATE(), INTERVAL 6 DAY) AND appointment_date <= CURDATE() GROUP BY appointment_date");
while ($weekResult && $row = $weekResult->fetch_assoc()) {
    $dayIndex = array_search($row['appointment_date'], $weekDates, true);
    if ($dayIndex !== false) $weekCounts[$dayIndex] = (int)$row['total'];
}
$weekMax = max(1, ...$weekCounts);

$statusResult = $conn->query("SELECT status, COUNT(*) total FROM appointments GROUP BY status ORDER BY total DESC");
$appointmentStatuses = [];
while ($statusResult && $row = $statusResult->fetch_assoc()) $appointmentStatuses[] = $row;
$statusTotal = array_sum(array_map(static fn($row) => (int)$row['total'], $appointmentStatuses));
$chartColors = ['#087a66', '#e0a33b', '#d65b5b', '#6f82b7', '#4aa98e', '#9973a8'];
$statusGradient = [];
$statusStart = 0;
foreach ($appointmentStatuses as $index => $row) {
    $statusEnd = $statusTotal ? $statusStart + ((int)$row['total'] / $statusTotal * 100) : 0;
    $statusGradient[] = $chartColors[$index % count($chartColors)] . " {$statusStart}% {$statusEnd}%";
    $statusStart = $statusEnd;
}
$departmentResult = $conn->query("SELECT dp.dept_name department_name, COUNT(a.appointment_id) total FROM departments dp LEFT JOIN doctors d ON d.dept_id = dp.dept_id LEFT JOIN appointments a ON a.doctor_id = d.doctor_id GROUP BY dp.dept_id, dp.dept_name ORDER BY total DESC, dp.dept_name LIMIT 6");
$departmentStats = [];
while ($departmentResult && $row = $departmentResult->fetch_assoc()) $departmentStats[] = $row;
$departmentTotal = array_sum(array_map(static fn($row) => (int)$row['total'], $departmentStats));
$departmentGradient = [];
$departmentStart = 0;
foreach ($departmentStats as $index => $row) {
    $departmentEnd = $departmentTotal ? $departmentStart + ((int)$row['total'] / $departmentTotal * 100) : 0;
    $departmentGradient[] = $chartColors[$index % count($chartColors)] . " {$departmentStart}% {$departmentEnd}%";
    $departmentStart = $departmentEnd;
}

include __DIR__ . "/includes/header.php";
?>

<div class="welcome">
    <div>
        <h1>Hospital Management</h1>
        <p>Here's what's happening at your hospital today.</p>
    </div>

    <div class="date">
        <?= date("D, d M Y") ?>
    </div>
</div>

<div class="stats">

<?php
$stats = [
    ["♙", "Total Patients", $patients, "Registered patients"],
    ["◫", "Today's Appointments", $appointments, "Scheduled appointments"],
    ["♟", "Total Doctors", $doctors, "All departments"],
    ["₹", "Total Revenue", "₹ " . number_format($bills, 0), "From recorded bills"]
];

foreach ($stats as $s):
?>

<div class="card stat">

    <div>
        <div class="stat-icon"><?= $s[0] ?></div>

        <h3><?= htmlspecialchars($s[2]) ?></h3>

        <p><?= htmlspecialchars($s[1]) ?></p>

        <div class="trend">
            ↗ Live database value
        </div>
    </div>

</div>

<?php endforeach; ?>

</div>


<div class="grid3">

    <!-- Patient Statistics -->
    <div class="card panel">

            <h2>Appointments, Last 7 Days</h2>

        <div class="chart">

            <?php
            foreach ($weekDates as $i => $chartDate):
                $height = $weekCounts[$i] ? max(5, (int)round($weekCounts[$i] / $weekMax * 100)) : 2;
            ?>

            <div
                class="bar"
                style="height:<?= $height ?>%"
                data-day="<?= date('D', strtotime($chartDate)) ?>"
                title="<?= date('D, d M', strtotime($chartDate)) ?>: <?= $weekCounts[$i] ?> appointments"
                role="img"
                aria-label="<?= date('D, d M', strtotime($chartDate)) ?>: <?= $weekCounts[$i] ?> appointments">
            </div>

            <?php endforeach; ?>

        </div>

    </div>


    <!-- Appointment Statistics -->
    <div class="card panel">

            <h2>Appointments by Status</h2>

        <div class="donut" data-count="<?= $statusTotal ?>" role="img" aria-label="<?= $statusTotal ?> appointments by status" style="background:<?= $statusTotal ? 'conic-gradient(' . htmlspecialchars(implode(', ', $statusGradient)) . ')' : '#dcebe7' ?>"></div>

        <div class="legend">

            <?php foreach ($appointmentStatuses as $i => $status): ?>
            <span><i class="dot" style="background:<?= $chartColors[$i % count($chartColors)] ?>"></i>
                <?= htmlspecialchars($status['status']) ?> <?= $statusTotal ? (int)round((int)$status['total'] / $statusTotal * 100) : 0 ?>%
            </span>
            <?php endforeach; ?>
            <?php if (!$appointmentStatuses): ?><span>No appointment data</span><?php endif; ?>

        </div>

    </div>


    <!-- Department Statistics -->
    <div class="card panel">

        <h2>Appointments by Department</h2>

        <div
            class="donut"
            role="img"
            data-count="<?= $departmentTotal ?>"
            aria-label="Appointment distribution by department"
            style="background:<?= $departmentTotal ? 'conic-gradient(' . htmlspecialchars(implode(', ', $departmentGradient)) . ')' : '#dcebe7' ?>">
        </div>

        <div class="legend">

            <?php foreach ($departmentStats as $i => $department): ?>
            <span><i class="dot" style="background:<?= $chartColors[$i % count($chartColors)] ?>"></i>
                <?= htmlspecialchars($department['department_name']) ?> — <?= $departmentTotal ? (int)round((int)$department['total'] / $departmentTotal * 100) : 0 ?>%
            </span>
            <?php endforeach; ?>
            <?php if (!$departmentStats): ?><span>No department data</span><?php endif; ?>

        </div>

    </div>

</div>


<div class="lists">

<?php

$queries = [

    [
        "Recent Appointments",
        "SELECT 
            p.name,
            a.appointment_date,
            a.status
        FROM appointments a
        JOIN patients p 
            ON p.patient_id = a.patient_id
        ORDER BY a.appointment_id DESC
        LIMIT 5"
    ],

    [
        "Recent Patient Registrations",
        "SELECT 
            name,
            age,
            gender,
            patient_id
        FROM patients
        ORDER BY patient_id DESC
        LIMIT 5"
    ],

    [
        "Upcoming Appointments",
        "SELECT 
            p.name,
            a.appointment_date,
            a.status
        FROM appointments a
        JOIN patients p 
            ON p.patient_id = a.patient_id
        WHERE a.appointment_date >= CURDATE()
        ORDER BY a.appointment_date
        LIMIT 5"
    ]

];

foreach ($queries as $q):

?>

<div class="card panel">

    <h2>
        <?= htmlspecialchars($q[0]) ?>

            <a
            href="<?= htmlspecialchars($basePath) ?>/<?= strpos(strtolower($q[0]), 'appointment') !== false ? 'appointments/' : 'patients/' ?>"
            class="view-all"
            style="
                float:right;
                color:#07906f;
                font-size:9px;
            ">
            View All
        </a>
    </h2>


<?php

$rs = $conn->query($q[1]);

if ($rs):

while ($r = $rs->fetch_assoc()):

?>

<div class="list-row">

    <div class="avatar">
        <?= strtoupper(substr($r['name'], 0, 1)) ?>
    </div>


    <div class="row-info">

        <b>
            <?= htmlspecialchars($r['name']) ?>
        </b>

        <small>

        <?php
        if (isset($r['age'])) {

            echo htmlspecialchars(
                $r['age'] . " yrs · " . $r['gender']
            );

        } else {

            echo htmlspecialchars(
                $r['appointment_date'] ?? ''
            );

        }
        ?>

        </small>

    </div>


    <span class="badge">

        <?= htmlspecialchars(
            $r['status'] ?? 'Active'
        ) ?>

    </span>

</div>

<?php

endwhile;

endif;

?>

</div>

<?php endforeach; ?>

</div>


<?php
include __DIR__ . "/includes/footer.php";
?>